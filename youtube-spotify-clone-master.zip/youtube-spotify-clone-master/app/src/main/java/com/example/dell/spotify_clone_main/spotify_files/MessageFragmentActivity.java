package com.example.dell.spotify_clone_main.spotify_files;

import android.os.Bundle;

import com.example.dell.spotify_clone_main.UI.spotify;

public class MessageFragmentActivity extends spotify {

}
