package com.example.dell.spotify_clone_main.adapters;
// view collab class
public class viewCollab {
    String email;

    public viewCollab(String email) {
        this.email = email;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
