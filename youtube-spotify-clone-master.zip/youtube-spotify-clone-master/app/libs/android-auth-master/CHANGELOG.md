Change Log
==========

## Version 1.1.1

_2018-02-28_

* Add  method to clear Spotify and Facebook cookies to AuthenticationClient
* Upgrade buildToolsVersion to 27.0.3
* Replace deprecated compile keyword in gradle files

## Version 1.1.0

_2018-02-28_

* Upgrade target and compile SDKs to 27
* Upgrade android support libraries to 27.0.2
